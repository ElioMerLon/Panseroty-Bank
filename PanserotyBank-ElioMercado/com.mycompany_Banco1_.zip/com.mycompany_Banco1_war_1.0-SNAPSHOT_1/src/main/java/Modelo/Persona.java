/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.text.DecimalFormat;

/**
 *
 * @author elio
 */
public class Persona {
    int id;
    String dni;
    public String nom1;
    String nom2;
    String ape1;
    String ape2;
    String estado;
    String user;
    String pass;
    double saldo;
    String tipoCuenta;
    
    public Persona(){
    }

    public Persona( String dni, String nom1, String nom2, String ape1, String ape2, String estado, String user, String pass,String tipoCuenta) {
        
        this.dni = dni;
        this.nom1 = nom1;
        this.nom2 = nom2;
        this.ape1 = ape1;
        this.ape2 = ape2;
        this.estado = estado;
        this.user = user;
        this.pass = pass;
        this.tipoCuenta = tipoCuenta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNom1() {
        return nom1;
    }

    public void setNom1(String nom1) {
        this.nom1 = nom1;
    }

    public String getNom2() {
        return nom2;
    }

    public void setNom2(String nom2) {
        this.nom2 = nom2;
    }

    public String getApe1() {
        return ape1;
    }

    public void setApe1(String ape1) {
        this.ape1 = ape1;
    }

    public String getApe2() {
        return ape2;
    }

    public void setApe2(String ape2) {
        this.ape2 = ape2;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    public String getFormattedSaldo() {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return df.format(saldo);
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }
    
}
