/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.Persona;
import ModeloDAO.PersonaDAO;
import java.io.IOException;

import jakarta.servlet.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author 32344
 */
public class Controlador extends HttpServlet {
    
    String listar = "listar.jsp";
    String add = "Add.jsp";
    
    String index = "index.jsp";
    String home = "Home.jsp";
    String tran= "Transaccion.jsp";
    Persona p = new Persona();
    PersonaDAO dao = new PersonaDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion=request.getParameter("accion");
        if(accion==null){
            accion="index.jsp";
        }
        try {
            switch (accion) {
                case "Home":
                    request.getRequestDispatcher("Home.jsp").forward(request, response);
                    break;
                default:
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    break;
                
            }
        } catch (Exception e) {
            throw new ServletException("Error processing request", e);
        }
        
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String acceso = "";
        String action = request.getParameter("accion");
        if (action.equalsIgnoreCase("listar")) {
            acceso = listar;
        } else if (action.equalsIgnoreCase("add")) {
            acceso = add;
        } else if (action.equalsIgnoreCase("index")) {
            acceso = index;
        }else if(action.equalsIgnoreCase("home")){
            acceso = home;
        } else if (action.equalsIgnoreCase("agregar")) {
            String tipoCuenta = request.getParameter("tipoCuenta");
            String dni = request.getParameter("txtDni");
            String pass = request.getParameter("txtpass");
            String nombre1 = request.getParameter("txtNombre1");
            String nombre2 = request.getParameter("txtNombre2");
            String ape1 = request.getParameter("txtApe1");
            String ape2 = request.getParameter("txtApe2");
            
            p.setTipoCuenta(tipoCuenta);
            p.setUser(dni);
            p.setPass(pass);
            p.setDni(dni);
            p.setNom1(nombre1);
            p.setNom2(nombre2);
            p.setApe1(ape1);
            p.setApe2(ape2);
            dao.add(p);

            
        }else if(action.equalsIgnoreCase("Pago")){
            acceso=tran;
        } /*else if(action.equalsIgnoreCase("actualizar")) {
            request.getRequestDispatcher("Edit.jsp").forward(request, response);
        }*/else {
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
        
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}

