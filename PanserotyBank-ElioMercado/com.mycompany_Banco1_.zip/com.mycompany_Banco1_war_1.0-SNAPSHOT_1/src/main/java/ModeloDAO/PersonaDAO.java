/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModeloDAO;

import Interfaces.CRUD;
import Modelo.Persona;
import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author elio 
 */
public class PersonaDAO implements CRUD {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public java.util.List<Persona> listar() {
        ArrayList<Persona> list = new ArrayList<>();
        String sql = "select * from cliente";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Persona per = new Persona();
                per.setId(rs.getInt("Id"));
                per.setDni(rs.getString("identificacion"));
                per.setNom1(rs.getString("nombre"));
                per.setNom2(rs.getString("nombre2"));
                per.setApe1(rs.getString("apellido"));
                per.setApe2(rs.getString("apellido2"));
                list.add(per);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Persona List() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean add(Persona per) {
        String sql = "insert into cliente(identificacion, nombre, nombre2, apellido, apellido2, usuario,password) values('"+per.getDni()+"','"+per.getNom1()+"','"+per.getNom2()+"','"+per.getApe1()+"','"+per.getApe2()+"','"+per.getUser()+"','"+per.getPass()+"')";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean edit(Persona per) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean eliminar(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
    public Persona validar(String user,String pass) throws SQLException{
        Persona per=new Persona();
        String sql="select * from cliente where usuario=? and password=?";
        try{
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            rs=ps.executeQuery();
            while(rs.next()){
                per.setUser(rs.getString("usuario"));
                per.setPass(rs.getString("password"));
                per.setNom1(rs.getString("nombre"));
                per.setSaldo(rs.getDouble("saldo"));
                per.setUser(rs.getString("apellido"));
                per.setUser(rs.getString("identificacion"));
                
            }
        }catch(Exception e){
            
        }finally {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        }
        return per;
    }
    public Persona enviar(String cuenta,String identificacion) throws SQLException{
        Persona per=new Persona();
        String sql="select * from cliente where tipoCuenta=? and identificacion=?";
        try{
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.setString(1, cuenta);
            ps.setString(2, identificacion);
            rs=ps.executeQuery();
            while(rs.next()){
                per.setUser(rs.getString("usuario"));
                per.setNom1(rs.getString("nombre"));
                per.setSaldo(rs.getDouble("saldo"));
                per.setUser(rs.getString("apellido"));
                per.setUser(rs.getString("identificacion"));
                
            }
        }catch(Exception e){
            
        }
        return per;
    }
}
